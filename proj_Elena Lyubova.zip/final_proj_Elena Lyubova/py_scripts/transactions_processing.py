import pandas as pd
from sqlalchemy import create_engine
from os import rename 


def create_and_set_schema(cursor, connection, schema_name):
    """
    Создает и активирует схему.
    """
    cursor.execute(f'CREATE SCHEMA IF NOT EXISTS {schema_name};')
    cursor.execute(f'SET search_path TO {schema_name};')
    
    connection.commit()

def trans_csv2sql(path, config, connection):
    """
    Считывает csv-файл и записывает данные в таблицу stg_transactions.
    """
    try: 
        connect_str = f"postgresql://{config['user']}:{config['password']}@{config['host']}:{config['port']}/{config['database']}"
        connection = create_engine(connect_str)
        df = pd.read_csv(path, sep=';', header=0, names=['trans_id', 'trans_date', 'amt', 'card_num', 'oper_type', 'oper_result', 'terminal'])
        df['amt'] = df['amt'].str.replace(',', '.')
        df['amt'] = df['amt'].astype(float)
        df.to_sql(name="stg_transactions", con=connection, schema="bank", if_exists="replace", index=False)
        rename(f'{path}', f'./archive/{path}.backup') 
    except FileNotFoundError as e:
        print("Файл не найден. Возможно Вы ошиблись при вводе даты или данные на эту дату уже были выгружены в БД.")
        print(e)

def create_dwh_fact_transactions(cursor, connection):
    """
    Создает таблицу фактов dwh_fact_transactions.
    """
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS dwh_fact_transactions(
            trans_id varchar(128), 
            card_num varchar(128),
            account_num varchar(128),
            client_id varchar(128),
            terminal_id varchar(128),
            trans_date TIMESTAMP,
            amt NUMERIC(10,2),
            oper_type varchar(128),
            oper_result varchar(128)
        );
    ''')
    connection.commit()

def create_stg_new_rows_to_fact_trans(cursor, connection):
    """
    Создает таблицу stg_new_rows_to_fact_trans 
    для внесения новых записей в таблицу фактов dwh_fact_trans. 
    """
    cursor.execute('''
        CREATE TABLE stg_new_rows_to_fact_trans AS
            SELECT
                t1.trans_id,
                t2.card_num,
                t3.account_num,
                t4.client_id,
                t5.terminal_id,
                t1.trans_date::TIMESTAMP,
                t1.amt,
                t1.oper_type,
                t1.oper_result
            FROM stg_transactions t1
            INNER JOIN dwh_dim_cards t2
            ON t1.card_num = t2.card_num
            INNER JOIN dwh_dim_accounts t3
            ON t2.account_num = t3.account_num
            INNER JOIN dwh_dim_clients t4
            ON t3.client = t4.client_id
            INNER JOIN stg_terminals t5
            ON t1.terminal = t5.terminal_id           
    ''')
    connection.commit()
    
def update_dwh_fact_transactions(cursor, connection):
    """
    Добавляет новые записи в таблицу фактов dwh_fact_transactions. 
    """
    cursor.execute('''
        INSERT INTO dwh_fact_transactions(
            trans_id, 
            card_num,
            account_num,
            client_id,
            terminal_id,
            trans_date,
            amt,
            oper_type,
            oper_result
        )
        SELECT
            trans_id, 
            card_num,
            account_num,
            client_id,
            terminal_id,
            trans_date,
            amt,
            oper_type,
            oper_result
        FROM stg_new_rows_to_fact_trans
    ''')
    connection.commit()
    
def create_dwh_dim_transactions_hist(cursor, connection):
    """
    Создает историческую таблицу транзакций dwh_dim_transactions_hist.
    """
    cursor.execute(''' 
        CREATE TABLE IF NOT EXISTS dwh_dim_transactions_hist(
            id SERIAL PRIMARY KEY,
            trans_id varchar(128),
            trans_date TIMESTAMP,
            amt NUMERIC(10,2),
            oper_type varchar(128),
            oper_result varchar(128),
            card_num varchar(128),
            account_num varchar(128),
            valid_to date,
            client_id varchar(128),
            last_name varchar(128), 
            first_name varchar(128), 
            patronymic varchar(128), 
            date_of_birth date,
            passport_num varchar(128), 
            passport_valid_to date, 
            phone varchar(128),
            terminal_id varchar(128),
            terminal_type varchar(128),
            terminal_city varchar(128),
            terminal_address varchar(128),
            deleted_flg NUMERIC(1) DEFAULT 0,
            effective_from TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            effective_to TIMESTAMP DEFAULT '2999-12-31 23:59:59'
        );
    ''')
    connection.commit()
    

def create_stg_new_rows_to_trans_hist(cursor, connection):
    """
    Создает таблицу stg_new_rows_to_trans_hist 
    для внесения новых записей в историческую таблицу 
    транзакций dwh_dim_transactions_hist.
    """
    cursor.execute('''
        CREATE TABLE stg_new_rows_to_trans_hist AS
            SELECT 
                t1.trans_id,
                t1.trans_date,
                t1.amt,
                t1.oper_type,
                t1.oper_result,
                t1.card_num, 
                t3.account_num, 
                t3.valid_to,
                t4.client_id,
                t4.last_name, 
                t4.first_name, 
                t4.patronymic,
                t4.date_of_birth,
                t4.passport_num, 
                t4.passport_valid_to, 
                t4.phone,
                t5.terminal_id,
                t5.terminal_type,
                t5.terminal_city,
                t5.terminal_address
            FROM 
            dwh_fact_transactions t1
            INNER JOIN dwh_dim_cards t2
            ON t1.card_num = t2.card_num
            INNER JOIN dwh_dim_accounts t3
            ON t1.account_num = t3.account_num
            INNER JOIN dwh_dim_clients t4
            ON t1.client_id = t4.client_id
            INNER JOIN stg_terminals t5
            ON t1.terminal_id = t5.terminal_id
            WHERE trans_id NOT IN (SELECT trans_id FROM dwh_dim_transactions_hist);
    ''')
    connection.commit()
    
def update_dwh_dim_transactions_hist(cursor, connection):
    """
    Добавляет новые записи в историческую таблицу 
    транзакций dwh_dim_transactions_hist.
    """
    cursor.execute('''
        INSERT INTO dwh_dim_transactions_hist(
            trans_id,
            trans_date,
            amt,
            oper_type,
            oper_result,
            card_num, 
            account_num, 
            valid_to,
            client_id,
            last_name, 
            first_name, 
            patronymic,
            date_of_birth,
            passport_num, 
            passport_valid_to, 
            phone,
            terminal_id,
            terminal_type,
            terminal_city,
            terminal_address
        )
        SELECT
            trans_id,
            trans_date,
            amt,
            oper_type,
            oper_result,
            card_num, 
            account_num, 
            valid_to,
            client_id,
            last_name, 
            first_name, 
            patronymic,
            date_of_birth,
            passport_num, 
            passport_valid_to, 
            phone,
            terminal_id,
            terminal_type,
            terminal_city,
            terminal_address
        FROM stg_new_rows_to_trans_hist
    ''')
    connection.commit()
    
def remove_stg_tables(cursor, connection):
    """
    Удаляет стейджинговые таблицы и таблицы для выделения инкремента.
    """
    cursor.execute('''
        SELECT table_name
        FROM information_schema.TABLES
        WHERE table_schema = 'bank'
        AND table_name LIKE 'stg_%';
    ''')
    for i in cursor.fetchall():
        cursor.execute(f'DROP TABLE IF EXISTS {i[0]}')
    connection.commit()

        
        
        
        
