ALTER TABLE cards RENAME TO dwh_dim_cards;
ALTER TABLE dwh_dim_cards RENAME COLUMN account TO account_num;

ALTER TABLE accounts RENAME TO dwh_dim_accounts;
ALTER TABLE dwh_dim_accounts RENAME COLUMN account TO account_num;

ALTER TABLE clients RENAME TO dwh_dim_clients;