import pandas as pd

def create_rep_fraud(cursor, connection):
    """
    Создает таблицу с отчетом по мошенническим операциям.
    """
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS rep_fraud(
            id SERIAL PRIMARY KEY,
            event_dt TIMESTAMP,
            passport varchar(128),
            fio varchar(128),
            phone varchar(128),
            event_type varchar(128),
            report_dt TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
    ''')
    connection.commit()
    
def create_stg_new_rows_passport_to_rep_fraud(cursor, connection):
    """
    Создает таблицу stg_new_rows_passport_to_rep_fraud 
    для внесения новых записей при выявлении операций,
    совершенных при просроченном или заблокированном паспорте,
    в таблицу с отчетом rep_fraud.
    """
    cursor.execute('''
        CREATE TABLE stg_new_rows_passport_to_rep_fraud AS
           SELECT  
                t1.event_dt,
                t1.passport_num,
                CONCAT(last_name, ' ', first_name, ' ', patronymic) AS fio,
                t2.phone,
                'Совершение операции при просроченном или заблокированном паспорте.' AS event_type
            FROM (
            SELECT 
               passport_num,
               min(trans_date) AS event_dt
            FROM stg_new_rows_to_trans_hist
            WHERE (passport_valid_to IS NOT NULL AND trans_date > passport_valid_to + INTERVAL '1 day')
            OR passport_num IN(
                SELECT passport_num 
                FROM stg_passport_blacklist
            )
            GROUP BY passport_num) t1
            INNER JOIN dwh_dim_clients t2
            ON t1.passport_num = t2.passport_num;
    ''')
    connection.commit() 
    
def create_stg_new_rows_account_to_rep_fraud(cursor, connection):
    """
    Создает таблицу stg_new_rows_account_to_rep_fraud
    для внесения новых записей при выявлении операций,
    совершенных при недействующем договоре,
    в таблицу с отчетом rep_fraud.
    """
    cursor.execute('''
        CREATE TABLE stg_new_rows_account_to_rep_fraud AS
            SELECT 
                t1.event_dt,
                t1.passport_num,
                CONCAT(last_name, ' ', first_name, ' ', patronymic) AS fio,
                t2.phone,
                'Совершение операции при недействующем договоре.' AS event_type
            FROM (
                (SELECT 
                    min(trans_date) AS event_dt,
                    passport_num 
                FROM stg_new_rows_to_trans_hist
                WHERE valid_to IS NOT NULL AND trans_date > valid_to + INTERVAL '1 day'
                GROUP BY passport_num) t1
                INNER JOIN dwh_dim_clients t2
                ON t1.passport_num = t2.passport_num);
    ''')
    connection.commit() 
    
def create_stg_new_rows_city_to_rep_fraud(cursor, connection):
    """
    Создает таблицу stg_new_rows_city_to_rep_fraud
    для внесения новых записей при выявлении операций,
    совершенных в разных городах в течение 1 часа,
    в таблицу с отчетом rep_fraud.
    """
    cursor.execute('''
        CREATE TABLE stg_new_rows_city_to_rep_fraud AS
            SELECT 
                t1.event_dt,
                t1.passport_num,
                CONCAT(last_name, ' ', first_name, ' ', patronymic) AS fio,
                t2.phone,
                'Совершение операций в разных городах в течение одного часа.' AS event_type	
            FROM (
                SELECT 
                    min(trans_date) AS event_dt,
                    passport_num	
                FROM (
                SELECT  *,
                (trans_date - LAG(trans_date) OVER (ORDER BY trans_date)) AS delta, 
                LAG(terminal_city) OVER (ORDER BY trans_date) AS prev_city
                FROM stg_new_rows_to_trans_hist
                WHERE passport_num IN (
                SELECT passport_num 
                FROM stg_new_rows_to_trans_hist 
                GROUP BY passport_num
                HAVING count(DISTINCT terminal_city) > 1)
                )
                WHERE delta <= '01:00:00' AND terminal_city <> prev_city
                GROUP BY passport_num) t1
                INNER JOIN dwh_dim_clients t2
                ON t1.passport_num = t2.passport_num;
    ''')
    connection.commit() 

def create_stg_new_rows_try_amt_to_rep_fraud(cursor, connection):
    """
    Создает таблицу stg_new_rows_try_amt_to_rep_fraud
    для внесения новых записей при выявлении попытки подбора суммы
    в таблицу с отчетом rep_fraud.
    """
    cursor.execute('''
        CREATE TABLE stg_new_rows_try_amt_to_rep_fraud AS
            SELECT 
                trans_date AS event_dt,
                passport_num,
                fio,
                phone,
                'Попытка подбора суммы.' AS event_type
            FROM 
            (
            SELECT  
                passport_num,
                CONCAT(last_name, ' ', first_name, ' ', patronymic) AS fio,
                phone,
                card_num,
                trans_date,
                LAG(trans_date, 3) OVER (PARTITION BY card_num ORDER BY trans_date) AS time_prev_3,
                amt, 
                LAG (amt) OVER (PARTITION BY card_num ORDER BY trans_date) AS amt_prev_1,
                LAG (amt, 2) OVER (PARTITION BY card_num ORDER BY trans_date) AS amt_prev_2,
                LAG (amt, 3) OVER (PARTITION BY card_num ORDER BY trans_date) AS amt_prev_3,
                oper_result, 
                LAG (oper_result) OVER (PARTITION BY card_num ORDER BY trans_date) AS res_prev_1,
                LAG (oper_result, 2) OVER (PARTITION BY card_num ORDER BY trans_date) AS res_prev_2, 
                LAG (oper_result, 3) OVER (PARTITION BY card_num ORDER BY trans_date) AS res_prev_3

            FROM stg_new_rows_to_trans_hist
            )
            WHERE oper_result = 'SUCCESS' 
                AND res_prev_1 = 'REJECT' 
                AND res_prev_2 = 'REJECT'
                AND res_prev_3 = 'REJECT'
                AND (trans_date - time_prev_3) <= '00:20:00'
                AND (amt - amt_prev_1) < 0
                AND (amt_prev_1 - amt_prev_2) < 0 
                AND (amt_prev_2 - amt_prev_3) < 0;
    ''')
    connection.commit() 

def update_rep_fraud(cursor, connection):
    """
    Добавляет новые записи с выявленными мошенническими 
    операциями в таблицу с отчетом rep_fraud.
    """
    cursor.execute('''
        INSERT INTO rep_fraud(
            event_dt,
            passport,
            fio,
            phone,
            event_type
        ) 
            SELECT * FROM stg_new_rows_passport_to_rep_fraud
            UNION ALL 
            SELECT * FROM stg_new_rows_account_to_rep_fraud
            UNION ALL 
            SELECT * FROM stg_new_rows_city_to_rep_fraud
            UNION ALL
            SELECT * FROM stg_new_rows_try_amt_to_rep_fraud
            ORDER BY event_dt;
    ''')
    
    cursor.execute('''
        select * from rep_fraud;
    ''')
    
    rep_fraud = cursor.fetchall()
    df = pd.DataFrame(rep_fraud, columns=['id', 'event_dt', 'passport', ' fio', 'phone', 'event_type', 'report_dt'])
    print(df.to_string(index=False))

    connection.commit() 
    

        
        
        
        
