import json
import psycopg2

def get_config(path):
    """
    Чтение json файла, содержащего данные для соединения с DBeaver, 
    и преобразование данных JSON в объект Python
    """
    with open(path, 'r', encoding="UTF-8") as f:
        config = json.load(f)
    return config

def get_connection(config):
    """
    Подключение к серверу PostgreSQL
    """
    connection = psycopg2.connect(**config)
    return connection

def close(connection=None, cursor=None):
    """
    Закрытие соединения с БД
    """
    if cursor:
        cursor.close()
    if connection:
        connection.close()