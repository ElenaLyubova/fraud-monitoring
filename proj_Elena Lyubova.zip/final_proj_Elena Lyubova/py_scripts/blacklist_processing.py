import pandas as pd
from sqlalchemy import create_engine
from os import rename 

    
def blacklist_xlsx2sql(path, config, connection):
    """
    Считывает xlsx-файл и записывает данные в таблицу stg_passport_blacklist.
    """
    try:
        connect_str = f"postgresql://{config['user']}:{config['password']}@{config['host']}:{config['port']}/{config['database']}"
        connection = create_engine(connect_str)
        df = pd.read_excel(path, header=0, names=['entry_dt', 'passport_num'])
        df.to_sql(name="stg_passport_blacklist", con=connection, schema="bank", if_exists="replace", index=False)
        rename(f'{path}', f'./archive/{path}.backup')
    except FileNotFoundError as e:
        print("Файл не найден. Возможно Вы ошиблись при вводе даты или данные на эту дату уже были выгружены в БД.")
        print(e)
    
def create_dwh_fact_passport_blacklist(cursor, connection):
    """
    Создает таблицу фактов dwh_fact_passport_blacklist.
    """
    cursor.execute(''' 
        CREATE TABLE IF NOT EXISTS dwh_fact_passport_blacklist(
            passport_num varchar(128), 
            entry_dt date
        );
    ''')
    connection.commit()
    
def create_stg_new_rows_to_fact_blacklist(cursor, connection):
    """
    Создает таблицу stg_new_rows_to_fact_blacklist 
    для внесения новых записей в таблицу фактов dwh_fact_passport_blacklist.
    """
    cursor.execute('''
        CREATE TABLE stg_new_rows_to_fact_blacklist AS
            SELECT
                passport_num, 
                entry_dt
            FROM stg_passport_blacklist
            WHERE passport_num NOT IN
            (SELECT passport_num 
            FROM dwh_fact_passport_blacklist);
    ''')
    connection.commit()

def update_dwh_fact_passport_blacklist(cursor, connection):
    """
    Добавляет новые записи в таблицу фактов dwh_fact_passport_blacklist.
    """
    cursor.execute('''
        INSERT INTO dwh_fact_passport_blacklist(
            passport_num, 
            entry_dt
        )
        SELECT
            passport_num, 
            entry_dt
        FROM stg_new_rows_to_fact_blacklist
    ''')
    connection.commit()
    
def create_dwh_dim_passport_blacklist_hist(cursor, connection):
    """
    Создает историческую таблицу "черного списка" паспортов dwh_dim_passport_blacklist_hist.
    """
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS dwh_dim_passport_blacklist_hist(
            id SERIAL PRIMARY KEY,
            passport_num varchar(128),
            entry_dt date,
            deleted_flg NUMERIC(1) DEFAULT 0,
            effective_from TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            effective_to TIMESTAMP DEFAULT '2999-12-31 23:59:59'
        );
    ''')
    connection.commit()    

def create_stg_new_rows_to_blacklist_hist(cursor, connection):
    """
    Создает таблицу stg_new_rows_to_blacklist_hist 
    для внесения новых записей в историческую таблицу 
    dwh_dim_passport_blacklist_hist.
    """
    cursor.execute('''
        CREATE TABLE stg_new_rows_to_blacklist_hist AS
            SELECT 
                passport_num, 
                entry_dt    	
            FROM dwh_fact_passport_blacklist
            WHERE passport_num NOT IN
            (SELECT passport_num 
            FROM dwh_dim_passport_blacklist_hist)
    ''')
    connection.commit() 
    
def create_stg_deleted_rows_to_blacklist_hist(cursor, connection):
    """
    Создает таблицу stg_deleted_rows_to_blacklist_hist 
    для логического удаления из исторической таблицы 
    dwh_dim_passport_blacklist_hist паспортов, которые исключены
    из "черного списка".
    """
    cursor.execute('''
        CREATE TABLE stg_deleted_rows_to_blacklist_hist AS
            SELECT 
                passport_num, 
                entry_dt    	
            FROM dwh_dim_passport_blacklist_hist
            WHERE passport_num NOT IN
            (SELECT passport_num 
            FROM stg_passport_blacklist)
    ''')
    connection.commit() 
    
def update_dwh_dim_passport_blacklist_hist(cursor, connection):
    """
    Добавляет новые записи в историческую таблицу 
    dwh_dim_passport_blacklist_hist и отмечает как удаленные
    паспорта, которые исключены из "черного списка".
    """
    cursor.execute('''
        INSERT INTO dwh_dim_passport_blacklist_hist(
            passport_num, 
            entry_dt
        )
        SELECT
            passport_num, 
            entry_dt 
        FROM stg_new_rows_to_blacklist_hist
    ''')
    cursor.execute('''
        UPDATE dwh_dim_passport_blacklist_hist
        SET effective_to = NOW()- INTERVAL '1 second'
        WHERE passport_num IN (SELECT passport_num FROM stg_deleted_rows_to_blacklist_hist)
        AND effective_to = '2999-12-31 23:59:59';
    ''')
    cursor.execute('''   
        INSERT INTO dwh_dim_passport_blacklist_hist(
            passport_num, 
            entry_dt,
            deleted_flg
        )
        SELECT
            passport_num, 
            entry_dt,
            1
        FROM stg_deleted_rows_to_blacklist_hist
    ''') 
    
    connection.commit()
    
        
        
        
        
        
