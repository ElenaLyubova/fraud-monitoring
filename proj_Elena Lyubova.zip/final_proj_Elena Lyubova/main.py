from connect_to_postgre import *
from transactions_processing import *
from blacklist_processing import *
from terminals_processing import *
from create_report import *


date_of_data = '01032021' #Введите дату в формате 'DDMMYYYY'.

config = get_config(path) #Введите путь к файлу с данными для подключения к PostgreSQL

connection = get_connection(config)
cursor = connection.cursor()


create_and_set_schema(cursor, connection, 'bank')

remove_stg_tables(cursor, connection)


trans_csv2sql(f'transactions_{date_of_data}.csv', config, connection) 

terminals_xlsx2sql(f'terminals_{date_of_data}.xlsx', config, connection)

blacklist_xlsx2sql(f'passport_blacklist_{date_of_data}.xlsx', config, connection)


create_dwh_fact_transactions(cursor, connection)

create_dwh_dim_transactions_hist(cursor, connection)

create_stg_new_rows_to_fact_trans(cursor, connection)

update_dwh_fact_transactions(cursor, connection)

create_stg_new_rows_to_trans_hist(cursor, connection)

update_dwh_dim_transactions_hist(cursor, connection)


create_dwh_fact_passport_blacklist(cursor, connection)

create_dwh_dim_passport_blacklist_hist(cursor, connection)

create_stg_new_rows_to_fact_blacklist(cursor, connection)

update_dwh_fact_passport_blacklist(cursor, connection)

create_stg_new_rows_to_blacklist_hist(cursor, connection)

create_stg_deleted_rows_to_blacklist_hist(cursor, connection)

update_dwh_dim_passport_blacklist_hist(cursor, connection)


create_dwh_dim_terminals_hist(cursor, connection)

create_v_terminals(cursor, connection)

create_stg_new_rows_to_dwh_dim_terminals_hist(cursor, connection)

create_stg_updated_rows_to_dwh_dim_terminals_hist(cursor, connection)

update_dwh_dim_terminals_hist(cursor, connection)



create_rep_fraud(cursor, connection)

create_stg_new_rows_passport_to_rep_fraud(cursor, connection)

create_stg_new_rows_account_to_rep_fraud(cursor, connection)

create_stg_new_rows_city_to_rep_fraud(cursor, connection)

create_stg_new_rows_try_amt_to_rep_fraud(cursor, connection)

update_rep_fraud(cursor, connection)


