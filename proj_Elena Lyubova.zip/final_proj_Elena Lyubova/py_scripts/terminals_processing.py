import pandas as pd
from sqlalchemy import create_engine
from os import rename 

def terminals_xlsx2sql(path, config, connection):
    """
    Считывает xlsx-файл и записывает данные в таблицу stg_terminals.
    """
    try: 
        connect_str = f"postgresql://{config['user']}:{config['password']}@{config['host']}:{config['port']}/{config['database']}"
        connection = create_engine(connect_str)
        df = pd.read_excel(path)
        df.to_sql(name="stg_terminals", con=connection, schema="bank", if_exists="replace", index=False)
        rename(f'{path}', f'./archive/{path}.backup')
    except FileNotFoundError as e:
        print("Файл не найден. Возможно Вы ошиблись при вводе даты или данные на эту дату уже были выгружены в БД.")
        print(e)

def create_dwh_dim_terminals_hist(cursor, connection):
    """
    Создает историческую таблицу терминалов dwh_dim_terminals_hist.
    """
    cursor.execute(''' 
        CREATE TABLE IF NOT EXISTS dwh_dim_terminals_hist(
            id SERIAL PRIMARY KEY,
            terminal_id varchar(128),
            terminal_type varchar(128),
            terminal_city varchar(128),
            terminal_address varchar(128),
            deleted_flg NUMERIC(1) DEFAULT 0,
            effective_from TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            effective_to TIMESTAMP DEFAULT '2999-12-31 23:59:59'
        );
    ''')
    connection.commit()

def create_v_terminals(cursor, connection):
    """
    Создает представление исторической таблицы с действующими записями.
    """
    cursor.execute('DROP VIEW IF EXISTS v_terminals')
    
    cursor.execute(''' 
        CREATE VIEW v_terminals AS
            SELECT
                terminal_id,
                terminal_type,
                terminal_city,
                terminal_address
            FROM dwh_dim_terminals_hist
            WHERE effective_to = '2999-12-31 23:59:59'
            AND deleted_flg = 0
    ''')
    connection.commit()
    
def create_stg_new_rows_to_dwh_dim_terminals_hist(cursor, connection):
    """
    Создает таблицу stg_new_rows_to_dwh_dim_terminals_hist
    для внесения новых записей в таблицу dwh_dim_terminals_hist.
    """
    cursor.execute('''
        CREATE TABLE stg_new_rows_to_dwh_dim_terminals_hist AS
            SELECT 
                terminal_id,
                terminal_type,
                terminal_city,
                terminal_address
            FROM stg_terminals
            WHERE terminal_id NOT IN (SELECT terminal_id FROM dwh_dim_terminals_hist)
    ''')
    connection.commit()

def create_stg_updated_rows_to_dwh_dim_terminals_hist(cursor, connection):
    """
    Создает таблицу stg_updated_rows_to_dwh_dim_terminals_hist
    для внесения изменений в записи таблицы dwh_dim_terminals_hist.
    """
    cursor.execute('''
        CREATE TABLE stg_updated_rows_to_dwh_dim_terminals_hist AS
            SELECT 
                t2.terminal_id,
                t2.terminal_type,
                t2.terminal_city,
                t2.terminal_address
            FROM v_terminals t1 
            INNER JOIN stg_terminals t2
            ON t1.terminal_id = t2.terminal_id
            WHERE t1.terminal_type <> t2.terminal_type
                OR t1.terminal_city <> t2.terminal_city
                OR t1.terminal_address <> t2.terminal_address
    ''')
    connection.commit()
    
def update_dwh_dim_terminals_hist(cursor, connection):
    """
    Добавляет новые записи и вносит изменения в записи 
    исторической таблицы dwh_dim_terminals_hist.
    """
    
    cursor.execute('''
        INSERT INTO dwh_dim_terminals_hist(
            terminal_id,
            terminal_type,
            terminal_city,
            terminal_address
        )
        SELECT
            terminal_id,
            terminal_type,
            terminal_city,
            terminal_address
        FROM stg_new_rows_to_dwh_dim_terminals_hist
    ''')

    cursor.execute('''
        UPDATE dwh_dim_terminals_hist
        SET effective_to = NOW() - INTERVAL '1 second'
        WHERE terminal_id IN (SELECT terminal_id FROM stg_updated_rows_to_dwh_dim_terminals_hist)
        AND effective_to = '2999-12-31 23:59:59';
    ''')
    cursor.execute('''   
        INSERT INTO dwh_dim_terminals_hist(
            terminal_id,
            terminal_type,
            terminal_city,
            terminal_address
        )
        SELECT
            terminal_id,
            terminal_type,
            terminal_city,
            terminal_address
        FROM stg_updated_rows_to_dwh_dim_terminals_hist
    ''')
    connection.commit() 